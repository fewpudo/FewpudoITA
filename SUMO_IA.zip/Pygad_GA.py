from SUMO_simu_run import run_simu #possivelmente alterar para SUMO_simu_run

import pygad.kerasga
import os
def fitness_func(solution, sol_idx): #função de maximização -> retorna um número que representa o quão boa é a solução
    #fitness: velocidade média de cada simulação
    #solution é o vetor com pesos pre definidos**
    from main import model
    solution_weights = pygad.kerasga.model_weights_as_matrix(model=model, weights_vector=solution) #atualizo os pesos do modelo
    model.set_weights(solution_weights)
    fitness = run_simu(model) #velocidade média final de todos os carros
    return fitness
def callback_generation(ga_instance): #é acionada após o fim de cada geração
    #Randomizo o trânsito para nova geração
    dir = r'Sumo_demo' #diretório em que mapa está localizado
    cd = r'cd '
    cmd = r'randomTrips.py - n sjc.net.xml -r sjc.rou.xml -e 500 -l'
    os.system(cd + dir)
    os.system(cmd)
    #Imprimo dados da última geração
    print("Generation = {generation}".format(generation=ga_instance.generations_completed))
    print("Fitness    = {fitness}".format(fitness=ga_instance.best_solution()[1]))


