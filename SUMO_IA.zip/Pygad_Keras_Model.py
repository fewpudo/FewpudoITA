import tensorflow.keras as keras
import numpy as np
hidden_layer_percentage = 0.15

def predict(model, data_input): #é utilizado para predizer a próxima configuração dos sinais. É utilizado pela função run_simu
    #uso tensorflow pra encontrar outputs
    prediction = model.predict([data_input]) #checar se está dentro de uma lista
    output = np.round(prediction)
    return output
    #recebe input e devolve output

from SUMO_simu_run import set_var
n_ruas, n_sinais = set_var() #armazeno as características do mapa utilizado

def create_model():
    #defino camadas da rede neural
    input_layer  = keras.layers.Input(2*n_ruas) #recebo um vetor na forma [num de carros em cada rua, vel média em cada rua]
    dense_layer1 = keras.layers.Dense(int(hidden_layer_percentage*2*n_ruas), activation="relu")
    output_layer = keras.layers.Dense(n_sinais, activation="sigmoid") #retorno vetor com status atual de cada um dos sinais

    #crio modelo da rede neural
    model = keras.Sequential()
    model.add(input_layer)
    model.add(dense_layer1)
    model.add(output_layer)
    return model
