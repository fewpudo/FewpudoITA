from Pygad_Keras_Model import create_model
model = create_model() #tem que ser global?

import pygad.kerasga
from Pygad_GA import fitness_func, callback_generation



# Build the keras model using TF Sequential
keras_ga = pygad.kerasga.KerasGA(model=model, num_solutions = 2) #possivelmente alterar num_solutions
num_generations = 5
num_parents_mating = 2 #max 10
initial_population = keras_ga.population_weights #pesos randomizados

# Running the Genetic Algorithm to find the best weights
ga_instance = pygad.GA(num_generations=num_generations,
                       num_parents_mating=num_parents_mating,
                       initial_population=initial_population,
                       fitness_func=fitness_func,
                       on_generation=callback_generation)

ga_instance.run()

# Plotting the fitness results
ga_instance.plot_result(title="PyGAD & Keras - Iteration vs. Fitness", linewidth=4)

# Returning the details of the best solution.
solution, solution_fitness, solution_idx = ga_instance.best_solution()
print("Fitness value of the best solution = {solution_fitness}".format(solution_fitness=solution_fitness))
print("Index of the best solution : {solution_idx}".format(solution_idx=solution_idx))

# Fetch the parameters of the best solution.
best_solution_weights = pygad.kerasga.model_weights_as_matrix(model=model, weights_vector = solution)
model.set_weights(best_solution_weights)

# Saving the best solution
f = open("best_model", "w")
f.write(solution)
f.close()

