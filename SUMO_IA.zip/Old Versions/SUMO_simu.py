from Pygad_Keras_Model import predict

def set_traff_light_signals(output):
    pass
def read_traff_light_signals():
    pass
def run_simu(model) #recebe o modelo
    #rodo simulação do SUMO sem aparecer o SUMO
    #a cada X frames eu rodo predict. Então, atualizo os sinais
    t = 0
    while(t<100):
        data_input = read_traff_light_signals() #leio estado dos sinais
        output = predict(model, data_input)
        set_traff_light_signals(output)
        # ...

        t+=5 #time step
    avg_vel = 7 #setar valores
    return avg_vel
    #retorno a média das velocidades medias finais de todos os carros