from Pygad_Keras_Model import predict
-----------------------------

import os
import sys
import optparse

if 'SUMO_HOME' in os.environ:
	tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
	sys.path.append(tools)
else:
	sys.exit("please declare environment variable 'SUMO_HOME'")


from sumolib import checkBinary
import traci


def get_options():
	opt_parser = optparse.OptionParser()
	opt_parser.add_option("--nogui",action="store_true", default=False, help="run the commandline version of sumo")
	options, args = opt_parser.parse_args()
	return options



def run_simu(model):
	r = 0
	if __name__ == '__main__':
		options = get_options()


		'''if options.nogui:
			sumoBinary = checkBinary('sumo')
		else:
			sumoBinary = checkBinary('sumo-gui')'''

		sumoBinary = checkBinary('sumo')

		traci.start([sumoBinary, '-c', r'\Sumo_demo\my_config_file.sumocfg', '--tripinfo-output', r'\Sumo_demo\tripinfo.xml']) #testar e add no novo arquivo ****
		tf_names = traci.trafficlight.getIDList() #alterar localização e adicionar no novo arquivo****
		tf_num = traci.trafficlight.getIDCount() #alterar localização e adicionar no novo arquivo****
		r = run(model)
	return r
-----------------------------
def set_traff_light_signals(output):
	pass
def read_traff_light_signals():
	pass
def run(model):
	fitness = 0
	step = 0
	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()

		input_nn = []
		edge_list = traci.edge.getIDList()
		num_edges = traci.edge.getIDCount() #alterar localização e adicionar no novo arquivo****
		car_list = traci.vehicle.getIDList()
		v_m = 0
		#print(edge_list)

		for e in edge_list:
			input_nn.append(traci.edge.getLastStepVehicleNumber(e))
			if traci.edge.getLastStepVehicleNumber(e)==0:
				input_nn.append(0)
			else:
				input_nn.append(traci.edge.getLastStepMeanSpeed(e))
		#traci.edge.getWaitingTime()

		for car in car_list:
			if traci.vehicle.getSpeed(car)==0:
				fitness -= 5 #valor aleatorio
			else:
				fitness += traci.vehicle.getSpeed(car)
				v_m += traci.vehicle.getSpeed(car)
		if len(car_list)!=0:
			fitness = fitness/len(car_list)
			v_m = v_m/len(car_list)

		print(input_nn)
		if step%15 == 0: #a cada 15 frames o programa checa os semaforos
			outputs = predict(model, input_nn)
			for i in range(len(outputs)):
				if(outputs[i] == 1):
					traci.trafficlight.setPhase(tf_names[i], 2) ######alterar no arquivo novo
				else:
					traci.trafficlight.setPhase(tf_names[i], 0)
		#print(step)
		#if step >= 150 and step <=250:
		#	traci.trafficlight.setPhase("n1" , 2)
		step += 1
	fitness = fitness/step
	print(fitness)
	traci.close()
	sys.stdout.flush()
	return fitness