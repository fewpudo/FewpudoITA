
#-----------------------------

import os
import sys
import optparse

if 'SUMO_HOME' in os.environ:
	tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
	sys.path.append(tools)
else:
	sys.exit("please declare environment variable 'SUMO_HOME'")


from sumolib import checkBinary
import traci

#global tf_names, tf_num, edge_list, num_edges
def get_options():
	opt_parser = optparse.OptionParser()
	opt_parser.add_option("--nogui",action="store_true", default=False, help="run the commandline version of sumo")
	options, args = opt_parser.parse_args()
	return options


def set_var():
	sumoBinary = checkBinary('sumo')
	traci.start([sumoBinary, '-c', r'Sumo_demo\my_config_file.sumocfg', '--tripinfo-output',
				 r'Sumo_demo\tripinfo.xml'])  # testar***
	global tf_names
	tf_names = traci.trafficlight.getIDList()  # precisará ser global -> declarar na main?
	tf_num = traci.trafficlight.getIDCount()
	global edge_list
	edge_list = traci.edge.getIDList()
	num_edges = traci.edge.getIDCount()
	traci.close()
	return num_edges, tf_num
from Pygad_Keras_Model import predict
def run_simu(model):
	r = 0

	options = get_options()

	sumoBinary = checkBinary('sumo')

	traci.start([sumoBinary, '-c', r'Sumo_demo\my_config_file.sumocfg', '--tripinfo-output',
				r'Sumo_demo\tripinfo.xml'])  # testar***

	r = run(model)
	return r
#-----------------------------

def run(model):
	fitness = 0.0
	step = 0
	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()

		input_nn = []
		car_list = traci.vehicle.getIDList()
		v_m = 0.0

		for e in edge_list:
			input_nn.append(traci.edge.getLastStepVehicleNumber(e))
			if traci.edge.getLastStepVehicleNumber(e) == 0:
				input_nn.append(0)
			else:
				input_nn.append(traci.edge.getLastStepMeanSpeed(e))

		for car in car_list:
			if traci.vehicle.getSpeed(car) == 0:
				fitness -= 0.0 #valor aleatorio
			else:
				fitness += float(traci.vehicle.getSpeed(car)/len(car_list))
				v_m += float(traci.vehicle.getSpeed(car)/len(car_list))

		if step % 15 == 0:  # a cada 15 frames o programa checa os semaforos
			outputs = predict(model, input_nn)
			#print(outputs)
			for i in range(len(outputs)):
				if (outputs[0][i] == 1):
					traci.trafficlight.setPhase(tf_names[i], 2)
				else:
					traci.trafficlight.setPhase(tf_names[i], 0)
		step += 1
	fitness = float(fitness/100.0)
	print(fitness)
	traci.close()
	sys.stdout.flush()
	return fitness